

function [mcmc,schedule] = new_index_schedule(voronoi,params,mcmc,schedule)


if ( voronoi.grouping==1 && (mcmc.currType==0 || mcmc.currType==1 ) )
%  if (params.maxtiles==1)
%    schedule.tileIndx = [1:T]';
%    schedule.numtiles = T;
%    schedule.numrates = T;
%  else
%    Tindex = ones(T,1); K = 1;
%    isdone = (max(accumarray(Tindex,1))<=params.maxtiles);
%    while (~isdone && K<T)
%      [Tindex,center] = kmeans(voronoi.Scoord,K+1,'emptyaction','drop');
%      if sum(sum(center==NaN))
%        isdone = 1;
%      else
%        K = K+1;
%        isdone = (max(accumarray(Tindex,1))<=params.maxtiles);
%      end
%    end
%    [b,m,n] = unique(Tindex);
%    schedule.tileIndx = n;
%    schedule.numtiles = K;
%    schedule.numrates = K;
%  end
    T = voronoi.ntiles;
    eIndex = repeachcol(1:T,params.maxtiles);
    eIndex = eIndex(1:T);
    schedule.eIndex = eIndex';
    schedule.numtiles = max(eIndex);
    schedule.numrates = max(eIndex);
end
