

function [proposal,pi1_pi0,xtime,niter] = propose_thetas(kernel,params,Sstruct,diploid,schedule)
% In general, the acceptance probability is
%   posterior(t*)q(t*->tt)/posterior(tt)q(tt->t*)
% Under a symmetric proposal distribution
%   f(x|t*)pi(t*)/f(x|tt)pi(tt)
% On the log scale,
%   log(f(x|t*))+log(pi(t*))-log(f(x|tt))-log(pi(tt))
% Previously,
%   E1_E0 = log(f(x|t*))-log(f(x|tt))
% Now we combine two terms,
%   ll1_ll0 = log(f(x|t*))-log(f(x|tt))
%   pi1_pi0 = log(pi(t*))-log(pi(tt))
% The second term is 0 if the prior is uniform


thetai = schedule.thetatoupdate;
proposal.params = params;
proposal.type = 1;
proposal.subtype = thetai;
n = Sstruct.n;
xtime = 0;
niter = 0;

if (thetai==1)
  lambda = draw_theta(0,1,params.lambda,params.thetaS2);
  if (lambda>0 && lambda<1)
    pi1_pi0 = 0; % This corresponds to uniform(0,1) prior
  else
    pi1_pi0 = -Inf;
  end
  proposal.params.lambda = lambda;
elseif (thetai==2)
  mubar = draw_theta(0,1,params.mubar,params.thetaS2);
  if (mubar>0 && mubar<1)
    % This corresponds to Beta(sqrt(n),sqrt(n)*log(n)) prior
    % pi1_pi0 = log(betapdf(mubar,sqrt(n),sqrt(n)*log(n))) - ...
    %           log(betapdf(params.mubar,sqrt(n),sqrt(n)*log(n)));
    % pi1_pi0 = (       sqrt(n)-1)*(log(  mubar)-log(  params.mubar)) + ...
    %           (log(n)*sqrt(n)-1)*(log(1-mubar)-log(1-params.mubar));
    pi1_pi0 = 0; % This corresponds to uniform(0,1) prior
  else
    pi1_pi0 = -Inf;
  end
  proposal.params.mubar = mubar;
elseif (thetai==3)
  % Flip the ancestral/derived labels
  mubar = 1-params.mubar;
  if (mubar>0 && mubar<1)
    pi1_pi0 = 0; % This corresponds to uniform(0,1) prior
  else
    pi1_pi0 = -Inf;
  end
  proposal.params.mubar = mubar;
elseif (thetai==4)
  Zbar = Sstruct.Zbar;
  if (diploid)
    mubar = 2*params.mubar;
  else
    mubar =   params.mubar;
  end
  SSz = sum(realpow(Zbar-mubar,2));
  s2muv = rinvgam(0.5*n,0.5*SSz);
  proposal.params.s2muv = s2muv;
  % This guarantees that the proposal is always accepted
  pi1_pi0 = Inf;
elseif (thetai==5)
  noise = draw_theta(0,Inf,params.noise,params.thetaS2);
  if (noise>0)
    % This corresponds to pi(noise)\propto(1/noise)
    pi1_pi0 = log(params.noise)-log(noise);
  else
    pi1_pi0 = -Inf;
  end
  proposal.params.noise = noise;
elseif (thetai==6)
  df = draw_df(Sstruct.n,Sstruct.p,params.df);
  if (df>Sstruct.n && df<=Sstruct.p)
    % This corresponds to pi(df)\propto(1/df)
    pi1_pi0 = log(params.df)-log(df);
  else
    pi1_pi0 = -Inf;
  end
  proposal.params.df = df;
end
