

function ll = loss_function(Sstruct,UforSigma,params,diploid)
% Use the Cholesky decomposition of Sigma
%  Sstruct.p is the number of features (we sum over p independent sites)
%  Sstruct.n is the number of individuals (the number of dimensions of the r.v. Xi)

if isscalar(UforSigma)
  warning('LL:LogLikelihood','Input UforSigma is not a matrix.');
end

p = Sstruct.p;
n = Sstruct.n;
k = params.df;

if (diploid)
  muv = 2*params.mubar*ones(n,1);
else
  muv =   params.mubar*ones(n,1);
end

s2muv = params.s2muv;
SigmaSv = productAinvB(UforSigma,Sstruct.Sv);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ldSigmaSv = logdet(SigmaSv); %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ldSigma = logdet(UforSigma,'inv'); 
ldSigmaSv = Sstruct.ldSv-ldSigma;

% %%%% wishpdfln(Sstruct.Sv,k-1,[],Sigma) = 
% %%%% 0.5 * ( - trace(SigmaSv) + (k-1)*ldSigmaSv ...
% %%%%         - (n+1)*Sstruct.ldSv - (k-1)*n*log(2) -
% 2*mvngammaln((k-1)/2,n) )
ZZtbar = (Sstruct.Zbar-muv) *(Sstruct.Zbar-muv)';
ZtZbar = (Sstruct.Zbar-muv)'*(Sstruct.Zbar-muv) ;
SigmaZZtbar = productAinvB(UforSigma,ZZtbar);

% %%%% log pdf of the Normal(muv,Sigma/p) distribution
% %%%% log pdf of the Wishart((p-1)/(k-1)*Sigma,k-1) distribution
% ll0 = log(mvnpdf(Sstruct.Zbar,muv,Sigma/p)) + ...
% ll0 = mvnormpdfln(Sstruct.Zbar,muv,[],Sigma/p) + ...
%       wishpdfln(Sstruct.Sv,k-1,[],Sigma*(p-1)/(k-1));
% %%%% Do we achieve the effect of multiplying the wishart log-likelihood
% %%%% by (k-1)/(p-1), i.e., the effect of heating?
% ll = - ldSigma + n*log(k) - k*trace(SigmaZZtbar) - n*log(2*pi) ...
%      - trace(SigmaSv)*(k-1)/(p-1) + (k-1)*ldSigmaSv + n*(k-1)*log((k-1)/(p-1)) ...
%      - (n+1)*Sstruct.ldSv - (k-1)*n*log(2) - 2*mvngammaln((k-1)/2,n);

% %%%% log pdf of the Normal(muv,s2muv*I) distribution
% %%%% log pdf of the Wishart((p-1)/(k-1)*Sigma,k-1) distribution
% ll0 = mvnormpdfln(Sstruct.Zbar,muv,[],s2muv*eye(n)) + ...
%       wishpdfln(Sstruct.Sv,k-1,[],Sigma*(p-1)/(k-1));
ll = - n*log(s2muv) - ZtZbar/s2muv - n*log(2*pi) ...
     - trace(SigmaSv)*(k-1)/(p-1) + (k-1)*ldSigmaSv + n*(k-1)*log((k-1)/(p-1)) ...
     - (n+1)*Sstruct.ldSv - (k-1)*n*log(2) - 2*mvngammaln((k-1)/2,n);
ll = 0.5*ll;
% if abs(ll-ll0)>1e-8
%   error('Normal.Wishart',...
%         'Numerical error in computing the log likelihood.')
% end
