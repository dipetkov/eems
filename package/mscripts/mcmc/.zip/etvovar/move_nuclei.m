

function [proposal,pi1_pi0,xtime,niter,flag] = move_nuclei(kernel,params,voronoi,Mstruct,Astruct,soln,method,schedule)


% Using a truncated normal here means that the nuclei won't fall
% outside the habitat (changing the number of nuclei is handled
% as a different type of update)
T = voronoi.ntiles;
Errors = voronoi.Errors;
cRates = voronoi.cRates;
Scoord = voronoi.Scoord;

if (voronoi.grouping)
  eIndex = repmat(schedule.eIndex==schedule.tiletoupdate,1,2);
  xyS2 = repmat(voronoi.xyS2,T,1).*eIndex;
  Scoord = draw_moves(voronoi.minXY,voronoi.maxXY,Scoord,xyS2);
else
  Scoord(:,1) = draw_moves(voronoi.minXY(1),voronoi.maxXY(1),...
                           voronoi.Scoord(:,1),voronoi.xyS2(1));
  Scoord(:,2) = draw_moves(voronoi.minXY(2),voronoi.maxXY(2),...
                           voronoi.Scoord(:,2),voronoi.xyS2(2));
end

euDist = rdist(voronoi.Vcoord,Scoord);
[temp,Colors] = min(euDist,[],2);

if min(min(Scoord,[],1)>voronoi.minXY & max(Scoord,[],1)<voronoi.maxXY)
  tileMrates = realpow(10,Errors + params.ratesMu);
  tileCrates = realpow(10,cRates);
  Mx = 0.5*tileMrates(Colors(Mstruct.Mi))+0.5*tileMrates(Colors(Mstruct.Mj));
  Cx = tileCrates(Colors);
  [ETab,x,xtime,niter,flag] = sparse_solve_for_ET(Astruct,Cx,Mx,soln,method);
  [ETij,ETdi,oTinvo,oGinvo] = ETbar_from_ETab(ETab,kernel.Jindex);
  proposal = struct('type',{2},'subtype',{1},...
                    'x',{x},'Scoord',{Scoord},...
                    'euDist',{euDist},'Colors',{Colors},...
                    'ETij',{ETij},'oTinvo',{oTinvo},...
                    'ETdi',{ETdi},'oGinvo',{oGinvo});
  pi1_pi0 = 0;
else
  proposal = struct('type',{2},'subtype',{1},...
                    'Scoord',{Scoord});
  pi1_pi0 = -Inf;
  xtime = 0;
  niter = 0;
  flag = 0;
end
