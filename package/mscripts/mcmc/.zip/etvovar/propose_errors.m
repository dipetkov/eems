

function [proposal,pi1_pi0,xtime,niter,flag] = propose_errors(kernel,params,voronoi,Mstruct,Astruct,soln,method,schedule)


T = voronoi.ntiles;
Errors = voronoi.Errors;
cRates = voronoi.cRates;
Scoord = voronoi.Scoord;

if (voronoi.grouping)
  logmtS2 = params.logmtS2*(schedule.eIndex==schedule.ratetoupdate);
  Errors = draw_errors(params.absDiff,Errors,logmtS2);
else
  Errors = draw_errors(params.absDiff,Errors,params.logmtS2);
end

%% Constrain every error to lie within range
if min( abs(Errors)<params.absDiff )
  tileMrates = realpow(10,Errors + params.ratesMu);
  tileCrates = realpow(10,cRates);
  Mx = 0.5*tileMrates(voronoi.Colors(Mstruct.Mi)) + ...
       0.5*tileMrates(voronoi.Colors(Mstruct.Mj));
  Cx = tileCrates(voronoi.Colors);
  [ETab,x,xtime,niter,flag] = sparse_solve_for_ET(Astruct,Cx,Mx,soln,method);
  [ETij,ETdi,oTinvo,oGinvo] = ETbar_from_ETab(ETab,kernel.Jindex);
  proposal = struct('type',{3},'subtype',{1},...
                    'x',{x},'Errors',{Errors},...
                    'ETij',{ETij},'oTinvo',{oTinvo},...
                    'ETdi',{ETdi},'oGinvo',{oGinvo});
  pi1_pi0 = sum(dnorm(proposal.Errors,0,params.ratesS2)) ...
          - sum(dnorm(voronoi.Errors,0,params.ratesS2));
  niter = 0;
else
  proposal = struct('type',{3},'subtype',{1},...
                    'Errors',{Errors});
  pi1_pi0 = -Inf;
  xtime = 0;
  niter = 0;
  flag = 0;
end
