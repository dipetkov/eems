

datadir = '/phddata/petkova/data/simulated/geno/tribars-habitats';
habitat = 'd1-tribars100-wi-cond-s8x7-u4Nm1-L1000';
diploid = 1;

xPop = 8;
yPop = 7;

tmprt = 1;
simno = 3;


%function heat_run_mhmcmc0(datadir,habitat,xPop,yPop,diploid,tmprt,simno)


precond = 2;
method = default_solve_method(precond);
filebase = strcat( datadir,'/', habitat);
[nIndiv,nSites,Jcoord] = sample_information(filebase);

nPop = xPop*yPop;
grido = strcat('g',num2str(xPop),'x',num2str(yPop));
cholfunc = 0;
numtypes = 5;
errsbase = strcat( habitat,'-',grido,'-tmprt',num2str(tmprt),'-simno',num2str(simno));
filename = strcat(filebase,'-',grido,'-tmprt',num2str(tmprt),'-simno',num2str(simno));

fprintf(2,'Processing dataset %s\n',filebase)
fprintf(2,'       grid size = %s ....\n',grido)
fprintf(2,'       simulation = %d ....\n',simno)
fprintf(2,'       temperature = %.2f....\n',tmprt)

load(strcat('./endat/final-',errsbase,'.mat'))


mcmc = MCMC_print_performance(mcmc);
mcmchyperP = keep.hyperP(mcmc.ii,:);
mcmcthetas = keep.thetas(mcmc.ii,:);
mcmcNtiles = keep.Ntiles(mcmc.ii,:);
mcmcpilogl = keep.pilogl(mcmc.ii,:);
mcmcXcoord = keep.Xcoord(mcmc.ii);
mcmcYcoord = keep.Ycoord(mcmc.ii);
mcmcErrors = keep.Errors(mcmc.ii);
mcmcsizesE = keep.sizesE(mcmc.ii);
mcmcsizesF = keep.sizesF(mcmc.ii);

fprintf(2,'Initial prior:         %7.5f\n',initpi);
fprintf(2,'Initial loglikelihood: %7.5f\n',initll);
fprintf(2,'Final prior:           %7.5f\n',pi0);
fprintf(2,'Final loglikelihood:   %7.5f\n',ll0);

params.ratesMu
Errors = mcmcErrors{99};
mRates = realpow(10,Errors + params.ratesMu);

