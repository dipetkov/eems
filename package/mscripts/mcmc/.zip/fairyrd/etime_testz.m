

diploid = 0;
precond = 2;

tmprt = 1;
%simno = 12;

grouping = 0;
maxtiles = 1;

maxPop = 12;
xPop = 8;
yPop = 7;

datadir = '/phddata/petkova/data/fairy/data/';
habitat = 'haploid_fairywren_wout24';


for simno = 16:18
  
  heat_run_mhmcmc_noise1(datadir,habitat,maxPop,diploid,grouping,maxtiles,tmprt,simno);

end
