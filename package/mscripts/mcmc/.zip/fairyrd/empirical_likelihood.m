

%function [ll,mubar,Cov] = empirical_likelihood(datadir,habitat)
nSites = 1000;
nIndiv = 100;
FourNm = 0.1;
xPop = 7;
yPop = 7;


%title = 'uniform';
title = 'tribars';
datadir = strcat('/phddata/petkova/data/simulated/geno/tribars-habitats');
subtitle = strcat(title,num2str(nIndiv));
habitat = strcat(subtitle,'-wi-cond-s',num2str(xPop),'x',num2str(yPop),'-u4Nm',num2str(FourNm),'-L',num2str(nSites));




filebase = strcat( datadir,'/', habitat);
fprintf(2,'Processing dataset %s\n',filebase)

Z = dlmread(strcat(filebase,'.sites'));
IJX = dlmread(strcat(filebase,'.rates'));
M = full(sparse(IJX(:,1),IJX(:,2),IJX(:,3)));
ETab = sparse_solve_for_ET0(M,0);
Jindex = dlmread(strcat(filebase,'.ipmap'))';

nSites = nrow(Z);
nIndiv = ncol(Z);
Onevec = ones(nIndiv,1);
ETij = ETab(Jindex,Jindex);
ETii = diag(ETij);
ETij = ETij - diag(ETii);
ETdi = ETij - (1/2)*diag(ETii);
Tinvo = linsolve(ETij,Onevec);
Ginvo = linsolve(ETdi,Onevec);
oTinvo = Onevec'*Tinvo;
oGinvo = Onevec'*Ginvo;

% If the individuals are diploid, the mean is 2*mubar
% Here we just check that mean2 works okay
one = ones(1,nSites);
mubar0 = mean(Z)';
mubar1 = (one*Z)'/nSites;
ans = zeros(1,3);
ans(1) = approxequal(mubar0,mubar1);
mubar2 = mean2(Z);
ans(2) = approxequal(mubar0,mubar2);
mubar3 = mean2(strcat(filebase,'.sites'));
ans(3) = approxequal(mubar0,mubar3);
ans

% Here we just check that cov2 works okay
mubar = mean(Z);
Sigma0 = cov(Z);
mubar0 = ones(nSites,1)*mubar;
Sigma1 = (Z-mubar0)'*(Z-mubar0);
Sigma1 = Sigma1/(nSites-1);
ans(1) = approxequal(Sigma0,Sigma1);
Sigma2 = cov2(Z,mubar);
ans(2) = approxequal(Sigma0,Sigma2);
Sigma3 = cov2(strcat(filebase,'.sites'),mubar);
ans(3) = approxequal(Sigma0,Sigma3);
ans

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assume that the population is diploid
tree = dlmread(strcat(filebase,'.tree'));
tmrca = tree(2,1);
ttot = tree(2,2);
ans(1) = tmrca/ttot;
ans(2) = tree(2,3);
% Divide by 2 because the individuals are diploid
% Question: Why ans(2) = ans(3) ?
ans(3) = mean(mean(Z))/2;
ans
mubar = tmrca/ttot;
rho = 1/ttot;
sigma2 = mubar*(1-mubar);
lambda = rho/(sigma2*oGinvo);

Sigma = 4*sigma2 - 4*rho*ETdi;
Sigma0 = cov(Z);
temp = Sigma./Sigma0;
min(min(temp))
max(max(temp))

muv = 2*mubar*ones(nIndiv,1);
J = dlmread(strcat(filebase,'.ipmap'));
I = repmat(J,nIndiv,1);
Sigma0 = cov(Z);
Sigma0 = reshape(triu(Sigma0,1),nIndiv*nIndiv,1);
I1 = reshape(triu(I ,1),nIndiv*nIndiv,1);
I2 = reshape(triu(I',1),nIndiv*nIndiv,1);
Sigma = zeros(nIndiv,nIndiv);

for i = 1:nIndiv
for j = (i+1):nIndiv
  alpha = J(i);
  beta = J(j);
  gamma = (I1==alpha) & (I2==beta);
  gamma = gamma | (I2==alpha) & (I1==beta);
  Tab = Sigma0(gamma==1);
  Sigma(i,j) = mean(Tab);
  Sigma(j,i) = mean(Tab);
end
end

Sigma0 = cov(Z);

for i = 1:nIndiv
  alpha = J(i);
  gamma = (J==alpha);
  Taa = Sigma0(diag(gamma));
  Sigma(i,i) = mean(Taa);
end

ans = zeros(1,2);
UforSigma = chol(Sigma);
ll0 = log(mvnpdf(Z,muv',Sigma));
%ll1 = mvnormpdfln(Z',muv,[],Sigma)';
ll1 = mvnormpdfln(Z',muv,UforSigma)';
ans(1) = approxequal(ll0,ll1);
ll2 = mvnormpdflog(strcat(filebase,'.sites'),muv,Sigma);
ans(2) = approxequal(ll0,ll2);
ans

ll = sum(ll0);
fprintf(2,'The empirical log-likelihood is %7.5f\n',ll)

dlmwrite(strcat(filebase,'.empirll1'),[ll,mubar],'delimiter',' ','precision','%.6f');
%dlmwrite(strcat(filebase,'.empircov'),Sigma,'delimiter',' ','precision','%.6f');
