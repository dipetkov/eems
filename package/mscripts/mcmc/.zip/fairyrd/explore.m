

%datadir = '/phddata/petkova/data/simulated/geno/uniform-habitats';
%title = 'uniform';
datadir = '/phddata/petkova/data/simulated/geno/tribars-habitats';
prefix = 'd1';
title = 'tribars';
FourNm = 1;
nSites = 1000;
nIndiv = 100;
simno = 102;
xPop = 7;
yPop = 7;



subtitle = strcat(prefix,'-',title,num2str(nIndiv));
habitat  = strcat(subtitle,'-wi-cond-s',num2str(xPop),'x',num2str(yPop),'-u4Nm',num2str(FourNm),'-L',num2str(nSites));
truebase = strcat(subtitle,'-wi-cond-s',num2str(xPop),'x',num2str(yPop),'-u4Nm',num2str(FourNm),'-L',num2str(nSites));

XYconfig = strcat('g',num2str(xPop),'x',num2str(yPop));
filebase = strcat( datadir,'/', habitat);
errsbase = strcat( habitat,'-',XYconfig,'-simno',num2str(simno));
filename = strcat(filebase,'-',XYconfig,'-simno',num2str(simno));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(strcat('./endat/final-',errsbase,'.mat'))

mubars = keep.thetas(20001:end,1);
lambdas = keep.thetas(20001:end,2);
noise = keep.thetas(20001:end,3);
s2muv = keep.thetas(20001:end,4);
dfs = keep.thetas(20001:end,5);


[mean(mubars),mean(Sstruct.Zbar)/2]


% How much higher is the log likelihood if we rescale Sigma to match
% Sv/(nSites-1) ?

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% What is the true ETbar? the true Sigma?
Mijx = dlmread(strcat(filebase,'.rates'));
if approxequal(Mstruct.Mi,Mijx(:,1))~=1 
  error('test:solver','Failed: migration data structure.')
end
if approxequal(Mstruct.Mj,Mijx(:,2))~= 1
  error('test:solver','Failed: migration data structure.')
end

Mx = Mijx(:,3);
Cx = ones(nPop,1);
euDist = pdist2(Jcoord,Vcoord,'euclidean');
[temp,Jindex] = min(euDist,[],2);
[ETab,x,xtime,niter,flag] = sparse_solve_for_ET(Astruct,Cx,Mx,soln,method);
[ETij,ETdi,oTinvo,oGinvo] = ETbar_from_ETab(ETab,Jindex);
kernel0 = struct('Jindex',{Jindex},'Jcoord',{Jcoord},...
                 'ETij',{ETij},'oTinvo',{oTinvo},...
                 'ETdi',{ETdi},'oGinvo',{oGinvo});

kernel0.ETij(1:5,1:5)
kernel.ETij(1:5,1:5)
% This is of course 1 if using the true ETij matrix
I = triu(ones(nIndiv),1);
temp = kernel0.ETij./kernel.ETij;
mean(temp(I==1))

% Variability of within-deme coalescence times
% With the resistance distance, there is no variability
% Under symmetric migration, ave(ETaa) = nPop
[mean(diag(ETab)),nPop]
var(diag(ETab))


% The "true" parameters should be generated without conditioning,
% so use the "wo-cond" file
tree = dlmread(strcat(datadir,'/',truebase,'.tree'));
tmrca = 2*tree(1);
ttot = 2*tree(2);
mubar0 = tree(3);
s2snp0 = mubar0*(1-mubar0);
s2muv0 = 1/nSites;
rho0 = 1/ttot;
lambda0 = rho0/(s2snp0*oTinvo);
lambda1 = rho0/(s2snp0*oGinvo);
% I don't know what this parameter is equal to .....
%df0 = nSites/2;
df0 = mean(dfs);
noise0 = 0;

[mubar0,mean(mubars)]
[lambda0,mean(lambdas)]

Z = dlmread(strcat(filebase,'.sites'));
covZ = cov(Z);
Zbar = mean(Z,1);
mubar0 = mean(Zbar)/2;
s2snp0 = mubar0*(1-mubar0);
I = triu(ones(nIndiv),1);
temp = s2snp0 - covZ/4;
temp = temp./ETij;
rho = mean(temp(I==1))
var(temp(I==1))
lambda = rho/(s2snp0*oTinvo);
[lambda0,lambda]
ttot = 1/rho
[2*tree(2),ttot]


params0 = struct('lambda',{lambda0},'noise',{noise0},'mubar',{mubar0},'s2muv',{s2muv0},'s2snp',{s2snp0});
%params0 = params;
%params0.lambda = lambda0/2;
[Sigma0,UforSigma0] = form_Sigma_matrix(kernel0,params0,diploid,cholfunc);

temp = Sigma0./Sigma;
I = triu(ones(nIndiv),1);
D = eye(nIndiv);
[mean(temp(I==1)),var(temp(I==1))]
[mean(temp(D==1)),var(temp(D==1))]
wishpdfln(Sstruct.Sv,df0-1,[],Sigma*(nSites-1)/(df0-1))
wishpdfln(Sstruct.Sv,df0-1,[],Sigma0*(nSites-1)/(df0-1))


I = triu(ones(nIndiv));
temp = Sigma0./Sigma;
mean(temp(I==1))
Sv = Sstruct.Sv;
%temp = Sv./Sigma;
%mean(temp(I==1))
% I observe that the difference between Sigma0 and Sigma
% is about the same as the difference between the normalized
% sufficient statistic and Sigma
% Which Sigma gives a higher log likelihood
% Keeping everything else fixed how peaked it the likelihood
% surface for lambda?
temp = (Sv/(nSites-1))./Sigma;
kappa = mean(temp(I==1))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

