

homedir = '/phddata/petkova/';


addpath(strcat(homedir,'Documents/MATLAB/general'),'-end')
addpath(strcat(homedir,'Documents/MATLAB/project'),'-end')
addpath(strcat(homedir,'Documents/MATLAB/rdvovar'),'-end')
addpath(strcat(homedir,'Documents/MATLAB/methods'),'-end')
addpath(strcat(homedir,'Documents/MATLAB/wavelet'),'-end')

addpath(strcat(homedir,'local/matlab/mcmc'),'-end')
addpath(strcat(homedir,'local/matlab/marcel'),'-end')
addpath(strcat(homedir,'local/matlab/lightspeed'),'-end')
addpath(strcat(homedir,'local/matlab/NDLUTIL0p16'),'-end')

addpath(strcat(homedir,'src/4.2.3/ilupack-2.2/matlab'),'-end')
addpath(strcat(homedir,'src/4.2.3/SuiteSparse/CHOLMOD/MATLAB'),'-end')
