

function heat_run_mhmcmc0_noise1(datadir,habitat,xPop,yPop,diploid,grouping,maxtiles,tmprt,simno)


precond = 2;
method = default_solve_method(precond);
filebase = strcat( datadir,'/', habitat);
[nIndiv,nSites,Jcoord] = sample_information(filebase);

nPop = xPop*yPop;
grido = strcat('g',num2str(xPop),'x',num2str(yPop));
cholfunc = 0;
numtypes = 5;
errsbase = strcat( habitat,'-',grido,'-tmprt',num2str(tmprt),'-simno',num2str(simno));
filename = strcat(filebase,'-',grido,'-tmprt',num2str(tmprt),'-simno',num2str(simno));

fprintf(2,'Processing dataset %s\n',filebase);
fprintf(2,'       grid size = %s ....\n',grido);
fprintf(2,'       simulation = %d ....\n',simno);
fprintf(2,'       temperature = %.2f....\n',tmprt);

% Choose settings (manually)
Poinu = 9;
numthetas = 6;
numhyperp = 2;
thetaS2 = 0.0001;
logmtS2 = 0.001;
coordS2 = 0.001;

% First sseed the random number generator to a value based on the
% current time
seed = sum(100*clock);
seed = round(10000*seed)/10000;
fprintf(2,'Simulation runs with rng seed = %.6f\n',seed);
RandStream.setDefaultStream(RandStream('mt19937ar','seed',seed));

% Jcoord indicates the sample location of each lineage
% Jindex indicates the deme closest to each lineages
[nIndiv,nSites,Jcoord] = sample_information(filebase);
[Vcoord,Mij,A,Edges] = initializeMijA(filebase,xPop,yPop);

% Initial values for the theta parameters and the hyperparameters
mubar = unifrnd(0,1);
lambda = unifrnd(0,1);
noise = rexp(1,nIndiv);
s2muv = rexp(1,nIndiv);
df = nIndiv+1;
a = 6;
b = 3;
c = 0;
d = 0;
params = struct('lambda',{lambda},'df',{df},...
                'noise',{noise},'Poinu',{Poinu},...
                'mubar',{mubar},'s2muv',{s2muv},...
                's2muvA',{c},'s2muvB',{d},...
                'ratesA',{a},'ratesB',{b},...
                'thetaS2',{thetaS2},...
                'logmtS2',{logmtS2},...
                'numthetas',{numthetas},...
                'maxtiles',{maxtiles});

% Construct the sufficient statistic (Zbar,Sv)
Sstruct = suffstat_from_Sv(filebase);
 
% The first and second column in the sparse represenation
% of the weighted (migration) matrix do not need to be updated but
% the last column changes when
%   o) the Voronoi nuclei are moved around
%   o) the edge weights (rates) are updated
[Mstruct,Astruct,soln] = initialize_solver(filebase,nPop,Mij,A);
  
% To specify the migration rates between neighbors,
% we assign a rate (weight) to each tile, i.e., to all the edges that
% fall entire inside its interior. The rate of a
% connecting edge is the average of the two adjacent tile weights
[voronoi,params] = assign_random_errors(Vcoord,params,coordS2,grouping);
[kernel,soln,xtime,niter,flag] = distance_kernel(voronoi,params,Mstruct,Astruct,Jcoord,soln,method);
if (flag)
  save(strcat('./endat/error-',errsbase,'-didnt-converge.mat'));
  error('mcmc:Initialize','Method to solve A*x = b returned %d.',flag);
end

[Sigma,UforSigma] = form_Sigma_matrix_noise1(kernel,params,diploid,cholfunc);
if isscalar(UforSigma)
  save(strcat('./endat/error-',errsbase,'-Sigma-not-pd.mat'));
  error('mcmc:Initialize','Proposed values dont give a p.d. Sigma');
end

initpi = prior_term_errors(Sstruct,voronoi,params,diploid);
initll = loss_function(Sstruct,UforSigma,params,diploid);
fprintf(2,'Initial prior:         %7.5f\n',initpi);
fprintf(2,'Initial loglikelihood: %7.5f\n',initll);
if isnan(initll) || isinf(initpi) || isinf(initll)
  save(strcat('./endat/error-',errsbase,'-nan-loglikelihood.mat'));
  error('mcmc:Initialize','Log likelihood at starting point is NaN.');
end

% For MCMC sampling, choose the number of iterations as well as
% burn-in and thinning values
numIters = 60000;
saveIter = 10000;
burnin = 40000;
thinno = 199;
dimtypes = ones(numtypes,1);
dimtypes(1) = numthetas; % The first type of update is a nuisance param change
dimtypes(numtypes) = 2;  % The second type of update is birth/death of a tile
mcmc = MCMC_initialize(numIters,burnin,thinno,numtypes,dimtypes);

%save(strcat('./startat/initial-',errsbase,'.mat'));
dlmwrite(strcat(filename,'.edges'),Edges,'delimiter',' ');
dlmwrite(strcat(filename,'.coord'),Vcoord,'delimiter',' ');
dlmwrite(strcat(filename,'.ipmap'),kernel.Jindex,'delimiter',' ');
dlmwrite(strcat(filename,'.tiles'),voronoi.Scoord,'delimiter',' ');

[mcmc,schedule] = init_params_voronoi(voronoi,params,mcmc);
keep.hyperP = zeros(numIters,numhyperp);
keep.thetas = zeros(numIters,5);
keep.Ntiles = zeros(numIters,1);
keep.pilogl = zeros(numIters,2);
keep.Errors = cell(numIters,1);
keep.mRates = cell(numIters,1);
keep.Xcoord = cell(numIters,1);
keep.Ycoord = cell(numIters,1);
keep.sizesE = cell(numIters,1);
keep.sizesF = cell(numIters,1);

pi0 = initpi;
ll0 = initll;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Do not update the degrees of freedom in the beginning
schedule.numthetas = numthetas-1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while ~mcmc.isfinished

  mcmc = MCMC_start_iteration(mcmc);

  % These variables are necessary to compute the log likelihood and to
  % construct the covariance model
  % UforSigma: Cholesky decomposition of Sigma (the upper triangular matrix)
  % params:    lambda, mubar, noise, plus hyperparameters
  % voronoi:   information about voronoi tesselation
  % kernel:    the distance kernel matrix (either ETab or Rab)

  while ~mcmc.iterDone

    % Get a new configuration
    if (mcmc.currType==1)
      % Propose to update one theta parameter
      [proposal,pi1_pi0,xtime,niter] = propose_thetas(kernel,params,Sstruct,diploid,schedule);
      if isinf(pi1_pi0) && (pi1_pi0<0)
        ll1 = 0;
      else
        [newSigma,newUforSigma] = ...
            form_Sigma_matrix_noise1(kernel,proposal.params,diploid,cholfunc);
        ll1 = log_likelihood(Sstruct,newUforSigma,proposal.params,diploid);
      end
    elseif (mcmc.currType==2)
      % Propose to move the voronoi tiles around
      [proposal,pi1_pi0,xtime,niter,flag] = ...
          move_nuclei(kernel,params,voronoi,Mstruct,Astruct,soln,method,schedule);
      if isinf(pi1_pi0) && (pi1_pi0<0)
        ll1 = 0;
      else
        [newSigma,newUforSigma] = ...
            form_Sigma_matrix_noise1(proposal,params,diploid,cholfunc);
        ll1 = log_likelihood(Sstruct,newUforSigma,params,diploid);
      end
    elseif (mcmc.currType==3)
      % Propose to update the migration rates
      [proposal,pi1_pi0,xtime,niter,flag] = ...
          propose_errors(kernel,params,voronoi,Mstruct,Astruct,soln,method,schedule);
      if isinf(pi1_pi0) && (pi1_pi0<0)
        ll1 = 0;
      else
        [newSigma,newUforSigma] = ...
            form_Sigma_matrix_noise1(proposal,params,diploid,cholfunc);
        ll1 = log_likelihood(Sstruct,newUforSigma,params,diploid);
      end
    elseif (mcmc.currType==4)
      % Propose to update the mean migration log rate
      [proposal,pi1_pi0,xtime,niter,flag] = ...
          propose_ratesMu_noise1(kernel,params,voronoi,Mstruct,Astruct,soln,method);
      if isinf(pi1_pi0) && (pi1_pi0<0)
        ll1 = 0;
      else
        [newSigma,newUforSigma] = ...
            form_Sigma_matrix_noise1(proposal,params,diploid,cholfunc);
        ll1 = log_likelihood(Sstruct,newUforSigma,params,diploid);
      end
    elseif (mcmc.currType==5)
      % Propose the birth or the death of a tile
      [proposal,pi1_pi0,xtime,niter,flag] = ...
          propose_birth_death_noise1(kernel,params,voronoi,Mstruct,Astruct,soln,method);
      if isinf(pi1_pi0) && (pi1_pi0<0)
        ll1 = 0;
      else
        [newSigma,newUforSigma] = ...
            form_Sigma_matrix_noise1(proposal,params,diploid,cholfunc);
        ll1 = log_likelihood(Sstruct,newUforSigma,params,diploid);
      end
    end

    if (flag)
      save(strcat('./endat/error-',errsbase,'-Didnt-converge.mat'))
      error('mcmc:Iterate','Solve Ax=b (update=%d) failed to converge.',mcmc.currType);
    end
    if isnan(ll1)
      save(strcat('./endat/error-',errsbase,'-NaN-likelihood.mat'))
      error('mcmc:Iterate','Update of type %d produced NaN likelihood.',mcmc.currType);
    end

    % Metropolis-Hastings acceptance probability
    mcmc = MCMC_proceed(mcmc,proposal);
    u = runif(1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Heating/tempering: the likelihood or the posterior
    alpha = min(0,(pi1_pi0+ll1-ll0)/tmprt);
    %alpha = min(0,pi1_pi0+(ll1-ll0)/tmprt);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if (log(u)<alpha)
      [voronoi,kernel,params,soln] = accept_move(voronoi,kernel,params,soln,proposal);
      Sigma = newSigma; UforSigma = newUforSigma;
      pi0 = prior_term_errors(Sstruct,voronoi,params,diploid);
      ll0 = ll1;
      mcmc = MCMC_accept_proposal(mcmc);
    end

    if MCMC_exceeds_moves(mcmc,schedule)
      % Update the migration log rates hyper parameters (mean and variance)
      % This also changes the prior (altough not the likelihood term)
      [params,pi0] = update_hyperparameters(voronoi,params,mcmc,diploid,Sstruct);
      [mcmc,schedule] = new_index_schedule(voronoi,params,mcmc,schedule);
    end
    
    [mcmc,schedule] = MCMC_change_update(mcmc,schedule);

  end

  currErrors = voronoi.Errors;
  currmRates = realpow(10,currErrors + params.ratesMu);

  keep.hyperP(mcmc.currIter,:) = [params.ratesMu,params.ratesS2];
  keep.thetas(mcmc.currIter,:) = [params.mubar,params.lambda,params.noise,params.s2muv,params.df];
  keep.pilogl(mcmc.currIter,:) = [pi0,ll0];
  keep.Ntiles(mcmc.currIter) = voronoi.ntiles;
  keep.Errors{mcmc.currIter} = currErrors;
  keep.mRates{mcmc.currIter} = currmRates;
  keep.Xcoord{mcmc.currIter} = voronoi.Scoord(:,1);
  keep.Ycoord{mcmc.currIter} = voronoi.Scoord(:,2);
  keep.sizesE{mcmc.currIter} = count_empty_tiles(kernel,voronoi);
  keep.sizesF{mcmc.currIter} = count_pseudo_tiles(kernel,voronoi);

  mcmc = MCMC_end_iteration(mcmc,ll0);

  if ~mod(mcmc.currIter,saveIter)
    save(strcat('./endat/mhmcmc-',errsbase,'-i',num2str(mcmc.currIter),'.mat'));
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Start updating the degrees of freedom after the first 25% iterations
  % are up
  if mcmc.currIter == round(numIters/4)
    schedule.numthetas = numthetas;
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

save(strcat('./endat/final-',errsbase,'.mat'));

mcmc = MCMC_print_performance(mcmc);
mcmchyperP = keep.hyperP(mcmc.ii,:);
mcmcthetas = keep.thetas(mcmc.ii,:);
mcmcNtiles = keep.Ntiles(mcmc.ii,:);
mcmcpilogl = keep.pilogl(mcmc.ii,:);
mcmcXcoord = keep.Xcoord(mcmc.ii);
mcmcYcoord = keep.Ycoord(mcmc.ii);
mcmcErrors = keep.Errors(mcmc.ii);
mcmcmRates = keep.mRates(mcmc.ii);
mcmcsizesE = keep.sizesE(mcmc.ii);
mcmcsizesF = keep.sizesF(mcmc.ii);

fprintf(2,'Initial prior:         %7.5f\n',initpi);
fprintf(2,'Initial loglikelihood: %7.5f\n',initll);
fprintf(2,'Final prior:           %7.5f\n',pi0);
fprintf(2,'Final loglikelihood:   %7.5f\n',ll0);

runid = fopen(strcat('./rundata/',errsbase,'.txt'),'w');
fprintf(runid,'Processing dataset %s\n',filebase);
fprintf(runid,'       grid size = %s ....\n',grido);
fprintf(runid,'       simulation = %d ....\n',simno);
fprintf(runid,'       temperature = %.2f....\n\n',tmprt);
fprintf(runid,'Simulation runs with rng seed = %.6f\n\n',seed);
fprintf(runid,'Initial prior:         %7.5f\n',initpi);
fprintf(runid,'Initial loglikelihood: %7.5f\n',initll);
fprintf(runid,'Final prior:           %7.5f\n',pi0);
fprintf(runid,'Final loglikelihood:   %7.5f\n\n',ll0);
mcmc = MCMC_print_performance_tofile(mcmc,runid);
fclose(runid);

dlmwrite(strcat(filename,'.mcmchyperp'),mcmchyperP,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.mcmcthetas'),mcmcthetas,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.mcmcntiles'),mcmcNtiles,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.mcmcpilogl'),mcmcpilogl,'delimiter',' ','precision','%.5f');

dlmcell(strcat(filename,'.mcmcxcoord'),mcmcXcoord);
dlmcell(strcat(filename,'.mcmcycoord'),mcmcYcoord);
dlmcell(strcat(filename,'.mcmcerrors'),mcmcErrors);
dlmcell(strcat(filename,'.mcmcmrates'),mcmcmRates);
dlmcell(strcat(filename,'.mcmcsizese'),mcmcsizesE);
dlmcell(strcat(filename,'.mcmcsizesf'),mcmcsizesF);

dlmwrite(strcat(filename,'.keephyperp'),keep.hyperP,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.keepthetas'),keep.thetas,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.keepntiles'),keep.Ntiles,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.keeppilogl'),keep.pilogl,'delimiter',' ','precision','%.5f');

%dlmcell(strcat(filename,'.keepxcoord'),keep.Xcoord);
%dlmcell(strcat(filename,'.keepycoord'),keep.Ycoord);
%dlmcell(strcat(filename,'.keeperrors'),keep.Errors);
%dlmcell(strcat(filename,'.keepmrates'),keep.mRates);
%dlmcell(strcat(filename,'.keepsizese'),keep.sizesE);
%dlmcell(strcat(filename,'.keepsizesf'),keep.sizesF);

Zbar = Sstruct.Zbar;
Sv = Sstruct.Sv/(nSites-1);

%%% Note that this is the final Sigma matrix (after numIters)
%%% rather than the average posterior Sigma matrix
dlmwrite(strcat(filename,'.Sv'),Sv,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.Zbar'),Zbar,'delimiter',' ','precision','%.5f');
dlmwrite(strcat(filename,'.Sigma'),Sigma,'delimiter',' ','precision','%.5f');
