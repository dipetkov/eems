#!/bin/bash
# The name of the job, can be anything, simply used when displaying the list of running jobs
#$ -N fwetvovarz
# Giving the name of the output log file
#$ -o fwetvovarz.log
# Combining output/error messages into one file
#$ -j y
# One needs to tell the queue system to use the current directory as the working directory
# Or else the script may fail as it will execute in your top level home directory
#$ -cwd
#$ -V
#$ -l mem_free=2G
#$ -l h_vmem=3G
#$ -l h_fsize=2G


matlab -nodesktop -nojvm -nosplash -singleCompThread < etime_testz.m
