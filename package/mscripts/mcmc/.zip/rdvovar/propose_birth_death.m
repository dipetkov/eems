

function [proposal,pi1_pi0,xtime,niter,flag] = propose_birth_death(kernel,params,voronoi,Mstruct,Astruct,soln,method)


T = voronoi.ntiles;
u = runif(1);
if (T==1)
  % Since there must be at least one tile,
  % propose a birth
  u = 0;
end

if (u<0.5)
  % Propose birth
  ntiles = T+1;
  subtype = 1;
  center = runif(voronoi.minXY,voronoi.maxXY);
  Scoord = [voronoi.Scoord;center];
  euDist = rdist(voronoi.Vcoord,Scoord);
  [temp,Colors] = min(euDist,[],2);
  error = init_errors(1,params.absDiff,params.ratesS2);
  Errors = [voronoi.Errors;error];
  cRates = [voronoi.cRates;0];
  a_m1 = 0.5;
  a_m2 = 0.5;
  if T==1, a_m1 = 1; end
  pi1_pi0 = log(1-a_m2) - log(a_m1) + ...
            log(params.Poinu) - log(T+1);
else
  % Propose death
  ntiles = T-1;
  subtype = 2;
  i = rintunif(1,T);
  Scoord = voronoi.Scoord;
  Errors = voronoi.Errors;
  cRates = voronoi.cRates;
  Scoord(i,:) = [];
  Errors(i,:) = [];
  cRates(i,:) = [];
  euDist = rdist(voronoi.Vcoord,Scoord);
  [temp,Colors] = min(euDist,[],2);

  a_m1 = 0.5;
  a_m2 = 0.5;
  if T==2, a_m2 = 1;  end
  pi1_pi0 = log(a_m2) - log(1-a_m1) + ...
            log(T) - log(params.Poinu);
end

tileMrates = realpow(10,Errors + params.ratesMu);
tileCrates = realpow(10,cRates);
Mx = 0.5*tileMrates(Colors(Mstruct.Mi)) + ...
     0.5*tileMrates(Colors(Mstruct.Mj));
Cx = tileCrates(Colors);
[Rab,Jinvpt,xtime] = sparse_solve_for_R(Mstruct,Cx,Mx,kernel.Jindex);
[ETij,ETdi,oTinvo,oGinvo] = ETbar_from_ETab(Rab,Jinvpt);

niter = 0;
flag = 0;

proposal = struct('type',{5},'subtype',{subtype},...
                  'ntiles',{ntiles},'Scoord',{Scoord},...
                  'euDist',{euDist},'Colors',{Colors},...
                  'Errors',{Errors},'cRates',{cRates},...
                  'ETij',{ETij},'oTinvo',{oTinvo},...
                  'ETdi',{ETdi},'oGinvo',{oGinvo});
