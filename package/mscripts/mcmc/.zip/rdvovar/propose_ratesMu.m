

function [proposal,pi1_pi0,xtime,niter,flag] = propose_ratesMu(kernel,params,voronoi,Mstruct,Astruct,soln,method)


ratesMu = draw_theta(params.minRate,params.maxRate,...
                     params.ratesMu,params.logmtS2);
Errors = voronoi.Errors;
cRates = voronoi.cRates;

%% Constrain every error to lie within range
if ( ratesMu>params.minRate && ratesMu<params.maxRate )
  tileMrates = realpow(10,voronoi.Errors + ratesMu);
  tileCrates = realpow(10,voronoi.cRates);
  Mx = 0.5*tileMrates(voronoi.Colors(Mstruct.Mi)) + ...
       0.5*tileMrates(voronoi.Colors(Mstruct.Mj));
  Cx = tileCrates(voronoi.Colors);
  [Rab,Jinvpt,xtime] = sparse_solve_for_R(Mstruct,Cx,Mx,kernel.Jindex);
  [ETij,ETdi,oTinvo,oGinvo] = ETbar_from_ETab(Rab,Jinvpt);
  proposal = struct('type',{4},'subtype',{1},...
                    'ratesMu',{ratesMu},...
                    'ETij',{ETij},'oTinvo',{oTinvo},...
                    'ETdi',{ETdi},'oGinvo',{oGinvo});
  pi1_pi0 = 0;
  niter = 0;
  flag = 0;
else
  proposal = struct('type',{4},'subtype',{1},...
                    'ratesMu',{ratesMu});
  pi1_pi0 = -Inf;
  xtime = 0;
  niter = 0;
  flag = 0;
end
