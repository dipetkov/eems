

function [proposal,pi1_pi0,xtime,niter,flag] = propose_group_update(kernel,params,voronoi,Mstruct,Astruct,soln,method,schedule)


T = voronoi.ntiles;
Errors = voronoi.Errors;
cRates = voronoi.cRates;
Scoord = voronoi.Scoord;

if (voronoi.grouping)
  eIndex_update = (schedule.eIndex==schedule.tiletoupdate);
  Errors = draw_errors(params.absDiff,voronoi.Errors,...
                       params.logmtS2*eIndex_update);
  xyS2 = repmat(voronoi.xyS2,T,1).*repmat(eIndex_update,1,2);
  Scoord = draw_moves(voronoi.minXY,voronoi.maxXY,Scoord,xyS2);
else
  Errors = draw_errors(params.absDiff,Errors,params.logmtS2);
  Scoord(:,1) = draw_moves(voronoi.minXY(1),voronoi.maxXY(1),...
                           voronoi.Scoord(:,1),voronoi.xyS2(1));
  Scoord(:,2) = draw_moves(voronoi.minXY(2),voronoi.maxXY(2),...
                           voronoi.Scoord(:,2),voronoi.xyS2(2));
end

euDist = rdist(voronoi.Vcoord,Scoord);
[temp,Colors] = min(euDist,[],2);

%% Constrain every error and location to lie within range
if min(min( abs(Errors)<params.absDiff )) & ...
   min(min(Scoord,[],1)>voronoi.minXY & max(Scoord,[],1)<voronoi.maxXY)
  tileMrates = realpow(10,Errors + params.ratesMu);
  tileCrates = realpow(10,cRates);
  Mx = 0.5*tileMrates(Colors(Mstruct.Mi)) + ...
       0.5*tileMrates(Colors(Mstruct.Mj));
  Cx = tileCrates(Colors);
  [Rab,Jinvpt,xtime] = sparse_solve_for_R(Mstruct,Cx,Mx,kernel.Jindex);
  [ETij,ETdi,oTinvo,oGinvo] = ETbar_from_ETab(Rab,Jinvpt);
  proposal = struct('type',{3},...
                    'Errors',{Errors},'Scoord',{Scoord},...
                    'euDist',{euDist},'Colors',{Colors},...
                    'ETij',{ETij},'oTinvo',{oTinvo},...
                    'ETdi',{ETdi},'oGinvo',{oGinvo});
  pi1_pi0 = sum(dnorm(proposal.Errors,0,params.ratesS2)) ...
            -sum(dnorm(voronoi.Errors,0,params.ratesS2));
  niter = 0;
  flag = 0;
else
  proposal = struct('type',{3},'Errors',{Errors},'Scoord',{Scoord});
  pi1_pi0 = -Inf;
  xtime = 0;
  niter = 0;
  flag = 0;
end
