

function [voronoi,kernel,params,soln] = accept_move(voronoi,kernel,params,soln,proposal)


if (proposal.type==1)
  thefields = {'mubar','lambda','noise','s2muv'};
  numthetas = length(thefields);
  for i=1:numthetas
    afield = thefields(i);
    oldval = getfield(params,afield{:});
    newval = getfield(proposal.params,afield{:});
    if abs(oldval-newval)>0.1
      if (oldval>newval)
	fprintf(2,'  --- change %s from %.4f to %.4f\n',afield{:},oldval,newval);
      else
	fprintf(2,'  +++ change %s from %.4f to %.4f\n',afield{:},oldval,newval);
      end
    end
  end
  thefields = {'df'};
  numthetas = length(thefields);
  for i=1:numthetas
    afield = thefields(i);
    oldval = getfield(params,afield{:});
    newval = getfield(proposal.params,afield{:});
    if abs(oldval-newval)>10
      if (oldval>newval)
	fprintf(2,'  --- change %s from %.4f to %.4f\n',afield{:},oldval,newval);
      else
	fprintf(2,'  +++ change %s from %.4f to %.4f\n',afield{:},oldval,newval);
      end
    end
  end
  params = proposal.params;
elseif (proposal.type==2)
  % Moving a nuclei changes not only the nuclei coordinates
  % but the distances between demes and nuclei, the coloring
  % (i.e. the Voronoi tiling), and the pairs of neighboring demes
  voronoi.Scoord = proposal.Scoord;
  voronoi.euDist = proposal.euDist;
  voronoi.Colors = proposal.Colors;
  kernel.ETij = proposal.ETij;
  kernel.ETdi = proposal.ETdi;
  kernel.oTinvo = proposal.oTinvo;
  kernel.oGinvo = proposal.oGinvo;
elseif (proposal.type==3)
  voronoi.Errors = proposal.Errors;
  kernel.ETij = proposal.ETij;
  kernel.ETdi = proposal.ETdi;
  kernel.oTinvo = proposal.oTinvo;
  kernel.oGinvo = proposal.oGinvo;
elseif (proposal.type==4)
  oldval = params.ratesMu;
  newval = proposal.ratesMu;
  if abs(oldval-newval)>0.1
    if (oldval>newval)
      fprintf(2,'  --- change ratesMu from %.4f to %.4f\n',oldval,newval);
    else
      fprintf(2,'  +++ change ratesMu from %.4f to %.4f\n',oldval,newval);
    end
  end
  params.ratesMu = proposal.ratesMu;
  kernel.ETij = proposal.ETij;
  kernel.ETdi = proposal.ETdi;
  kernel.oTinvo = proposal.oTinvo;
  kernel.oGinvo = proposal.oGinvo;
elseif (proposal.type==5)
  oldval = voronoi.ntiles;
  newval = proposal.ntiles;
  if abs(oldval-newval)>0.1
    if (oldval>newval)
      fprintf(2,'  --- change ntiles from %d to %d\n',oldval,newval);
    else
      fprintf(2,'  +++ change ntiles from %d to %d\n',oldval,newval);
    end
  end
  voronoi.ntiles = proposal.ntiles;
  voronoi.Scoord = proposal.Scoord;
  voronoi.euDist = proposal.euDist;
  voronoi.Colors = proposal.Colors;
  voronoi.Errors = proposal.Errors;
  voronoi.cRates = proposal.cRates;
  kernel.ETij = proposal.ETij;
  kernel.ETdi = proposal.ETdi;
  kernel.oTinvo = proposal.oTinvo;
  kernel.oGinvo = proposal.oGinvo;
end
