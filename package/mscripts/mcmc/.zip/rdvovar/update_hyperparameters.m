

function [params,pi0] = update_hyperparameters(voronoi,params,mcmc,diploid,Sstruct)


if (mcmc.currType==3)
  ntiles = voronoi.ntiles;
  Errors = voronoi.Errors;
  SSe = Errors'*Errors;
  a = params.ratesA+ntiles;
  b = params.ratesB+SSe;
  ratesS2 = rinvgam(0.5*a,0.5*b);
  params.ratesS2 = ratesS2;
end

pi0 = prior_term_errors(Sstruct,voronoi,params,diploid);
